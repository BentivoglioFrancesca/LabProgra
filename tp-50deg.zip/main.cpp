/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <iostream>
using namespace std;

float ConvertirPiesaYardas(float pies) {
    return pies / 3.0;
}

float ConvertirPiesaPulgadas(float pies) {
    return pies * 12.0;
}

float ConvertirPiesaCentimetros(float pies) {
    return pies * 12.0 * 2.54;
}

float ConvertirPiesaMetros(float pies) {
    return ConvertirPiesaCentimetros(pies) / 100.0;
}

int main() {
float pies;

    cout << "Ingrese la medida en pies: ";
    cin >> pies;

float yardas = ConvertirPiesaYardas(pies);
float pulgadas = ConvertirPiesaPulgadas(pies);
float centimetros = ConvertirPiesaCentimetros(pies);
float metros = ConvertirPiesaMetros(pies);

    cout << "En Yardas: " << yardas <<endl;
    cout << "En Pies: " << pies <<endl;
    cout << "En Pulgadas: " << pulgadas <<endl;
    cout << "En Centímetros: " << centimetros <<endl;
    cout << "En Metros: " << metros <<endl;

    return 0;
}
