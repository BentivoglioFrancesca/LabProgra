/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std; 

void ImprimirLineaHorizontal() {
cout << "----------------------------------------" <<endl;
}

void Imprimir(int num) {
    for (int i = 1; i <= num; i++) {
        cout << i;

        if (i % 4 == 0) {
         cout << " (Múltiplo de 4)";
        }

        if (i % 9 == 0) {
         cout << " (Múltiplo de 9)";
        }

        cout <<endl;

        if (i % 5 == 0) {
            ImprimirLineaHorizontal();
        }
    }
}

int main() {
    int num = 500;
    Imprimir(num);

    return 0;
}
