/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include<bits/stdc++.h>
using namespace std;

void ImprimirCartel (int n);
int main()
{
    int n;
    cin>>n;
    ImprimirCartel(n);
   
   
    return 0;
}

void ImprimirCartel (int n)
{
    int i;
    for (i=0;i<n;i++)
    {
        cout<<"hola mundo "<<endl;
    }
}

