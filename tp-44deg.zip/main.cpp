/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <iostream>
#include <string>

using namespace std;

float calcularPromedio(float nota1, float nota2, float nota3) {
    return (nota1 + nota2 + nota3) / 3;
}

void mostrarMensaje(float promedio) {
    if (promedio >= 1 && promedio <= 6) {
        cout << "Desaprobó" << endl;
    } else if (promedio == 7) {
        cout << "Aprobó" << endl;
    } else if (promedio >= 8 && promedio <= 10) {
        cout << "Excelente" << endl;
    } else {
        cout << "El promedio ingresado no es válido" << endl;
    }
}

int main() {
    string nombre;
    float nota1, nota2, nota3, promedio;

    cout << "Ingrese el nombre del alumno: ";
    cin>>nombre;
    cout << "Ingrese la primera nota: ";
    cin >> nota1;

    cout << "Ingrese la segunda nota: ";
    cin >> nota2;

    cout << "Ingrese la tercera nota: ";
    cin >> nota3;

    promedio = calcularPromedio(nota1, nota2, nota3);

    cout << "El promedio del alumno " << nombre << " es: " << promedio << endl;

    mostrarMensaje(promedio);

    return 0;
}
