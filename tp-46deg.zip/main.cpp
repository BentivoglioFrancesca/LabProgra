/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

bool esNumeroPerfecto(int num) {
    int sumaDivisores = 0;

    for (int i = 1; i < num; i++) {
        if (num % i == 0) {
            sumaDivisores += i;
        }
    }

    return sumaDivisores == num;
}

void listarNumerosPerfectos(int cantidad) {
    int contador = 0;
    int numero = 2;

    while (contador < cantidad) {
        if (esNumeroPerfecto(numero)) {
            cout << numero << endl;
            contador++;
        }

        numero++;
    }
}

int main() {
    int cantidad = 10000;

    cout << "Los primeros " << cantidad << " números perfectos son:" << endl;
    listarNumerosPerfectos(cantidad);

    return 0;
}
