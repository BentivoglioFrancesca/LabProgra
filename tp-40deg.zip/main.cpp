/******************************************************************************

                              Online C++ Compiler.
               Code, Compile, Run and Debug C++ program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <iostream>
using namespace std;
int CalcularDoble (int num1);
int main()

{int num1,num2;
cout<<"ingrese num1: ";
cin>>num1;
int Doble;
Doble=CalcularDoble (num1);
cout<<Doble<<endl;

return 0;
}

int CalcularDoble (int num1)
{
return num1*2;
}

