/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
#include <string>

string InvertirPalabra(string palabra) {
    int longitud = palabra();
    for (int i = 0; i < longitud / 2; i++) {
    swap(palabra[i], palabra[longitud - i - 1]);
    }
    return palabra;
}

int main() {
    string palabra;
    cout << "Ingrese una palabra: ";
    cin >> palabra;

    string palabraInvertida=InvertirPalabra(palabra);
    cout << "Palabra invertida: "<<palabraInvertida <<endl;

    return 0;
}
