/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

bool esNumeroAbundante(int num) {
    int sumaDivisores = 0;

    for (int i = 1; i <= num / 2; i++) {
        if (num % i == 0) {
            sumaDivisores += i;
        }
    }

    return sumaDivisores > num;
}

void listarNumerosAbundantes(int cantidad) {
    int contador = 0;
    int numero = 12;

    while (contador < cantidad) {
        if (esNumeroAbundante(numero)) {
            cout << numero << endl;
            contador++;
        }

        numero++;
    }
}

int main() {
    int cantidad = 10000;

    cout << "Los primeros " << cantidad << " números abundantes son:" << endl;
    listarNumerosAbundantes(cantidad);

    return 0;
}
